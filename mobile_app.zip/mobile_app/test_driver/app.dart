import 'package:flutter_driver/driver_extension.dart';
import 'package:gyanvruksh/main.dart' as app;

void main() {
  // This line enables the extension.
  enableFlutterDriverExtension();

  // Call the `main()` function of your app or call `runApp` with your widget tree.
  app.main();
}
